package view;

public class MainApp {
	public static void main(String[] args) {
		System.out.print("***프로그램 시작합니다.***************");
		MenuView.menuChoice();
	}

}
